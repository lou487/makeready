// LMC Make Ready — JobTread Push Function
// Netlify serverless function — grant key never exposed to browser

const JT_URL = 'https://api.jobtread.com/pave';
const ORG_ID = '22PCgcUejSvr';
const GK = process.env.JT_GRANT_KEY || '22TN7BjW2xxVRX5wKXnkeRKu9TUwacQyKw';

async function jt(query) {
  const resp = await fetch(JT_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query: Object.assign({ '$': { grantKey: GK } }, query) })
  });
  const text = await resp.text();
  let result;
  try { result = JSON.parse(text); } catch(e) { throw new Error('Bad JSON: ' + text.substring(0,200)); }
  if (result.errors) throw new Error(JSON.stringify(result.errors));
  // Return data or empty object — let caller handle missing fields
  return result.data || result || {};
}

// Sanitize helpers
function cleanPhone(p) {
  if (!p) return '';
  const digits = p.replace(/[^0-9]/g, '');
  if (!digits) return '';
  if (digits.length === 10) return '+1' + digits;
  if (digits.length === 11 && digits[0] === '1') return '+' + digits;
  return '+' + digits;
}
function cleanEmail(e) { return e ? e.trim().toLowerCase() : ''; }
function cleanText(t) { return t ? t.trim().replace(/[<>{}|\\^`]/g, '') : ''; }
function cleanDate(d) {
  if (!d) return '';
  const m = d.match(/(\d{4}-\d{2}-\d{2})/);
  return m ? m[1] : '';
}

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Content-Type': 'application/json'
};

exports.handler = async function(event) {
  if (event.httpMethod === 'OPTIONS') return { statusCode: 200, headers: CORS, body: '' };
  if (event.httpMethod !== 'POST') return { statusCode: 405, headers: CORS, body: JSON.stringify({ error: 'Method not allowed' }) };

  const log = [];
  const ok  = (m) => log.push({ msg: m, cls: 'ok' });
  const err = (m) => log.push({ msg: m, cls: 'err' });
  const inf = (m) => log.push({ msg: m, cls: 'info' });

  try {
    const raw = JSON.parse(event.body);

    const addr       = cleanText(raw.addr) || '[Address]';
    const seller     = cleanText(raw.seller) || 'Client';
    const email      = cleanEmail(raw.email);
    const phone      = cleanPhone(raw.phone);
    const agent      = cleanText(raw.agent);
    const brokerage  = cleanText(raw.brokerage);
    const agentPhone = cleanPhone(raw.agentPhone);
    const agentEmail = cleanEmail(raw.agentEmail);
    const occ        = raw.occ || 'Vacant';
    const sqft       = (raw.sqft || '').replace(/[^0-9.]/g, '');
    const yearbuilt  = (raw.yearbuilt || '').replace(/[^0-9]/g, '');
    const access     = cleanText(raw.access);
    const listd      = cleanDate(raw.listd);
    const fin        = cleanText(raw.fin) || 'Not selected';
    const walknotes  = cleanText(raw.walknotes);
    const propnotes  = cleanText(raw.propnotes);
    const rooms      = raw.rooms || [];
    const selections = raw.selections || [];

    const occMap = { 'Occupied': 'Owner Occupied', 'Vacant': 'Vacant', 'Tenant occupied': 'Tenant Occupied' };

    // ── 1. Create seller account ──
    inf('Creating customer account...');
    const acctResp = await jt({
      createAccount: {
        '$': {
          organizationId: ORG_ID,
          name: seller,
          type: 'customer',
          customFieldValues: {
            'Needs': 'Other',
            'Lead score': '\u2b50\u2b50\u2b50',
            'Areas To Renovate (All That Apply)': 'Whole House',
            'Budget Range': 'Under $15,000',
            'Start Timeline': 'ASAP (within 2 weeks)',
            'Goal': 'Sell / List',
            'Property Currently Occupied?': occMap[occ] || 'Vacant',
            'Package Interest': 'Home Refresh',
            'Lead Source': 'Referral'
          }
        },
        createdAccount: { id: {}, name: {} }
      }
    });
    // Response may be {createAccount:{createdAccount:{id,name}}} or {data:{createAccount:...}}
    const acctNode = (acctResp.createAccount || (acctResp.data && acctResp.data.createAccount) || {}).createdAccount || {};
    const custId = acctNode.id;
    if (!custId) throw new Error('Could not get account ID from: ' + JSON.stringify(acctResp).substring(0,200));
    ok('Customer account created: ' + (acctNode.name || seller));

    // ── 2. Create location ──
    inf('Creating property location...');
    let locId = null;
    try {
      const locResp = await jt({
        createLocation: {
          '$': { accountId: custId, name: addr, address: addr },
          createdLocation: { id: {} }
        }
      });
      const locNode = (locResp.createLocation || (locResp.data && locResp.data.createLocation) || {}).createdLocation || {};
      locId = locNode.id;
      ok('Property location created');
    } catch(e) { err('Location warning: ' + e.message); }

    // ── 3. Create job ──
    inf('Creating job...');
    const t1 = rooms.filter(r => r.paintTier === 1).length;
    const t2 = rooms.filter(r => r.paintTier === 2).length;
    const t3 = rooms.filter(r => r.paintTier === 3).length;
    const roomSummary = rooms.map((r,i) => `${i+1}. ${r.label}${r.paintTier?' (T'+r.paintTier+')':''}`).join(', ');
    const selSummary = selections.map(s => `${s.name} (${s.finish}) x${s.qty}`).join(', ') || 'None';

    const desc = `PRE-LISTING MARKET PREP — SITE SURVEY\nFINISH: ${fin}\nROOMS: ${roomSummary}\nPAINT: T1=${t1} T2=${t2} T3=${t3}\nSELECTIONS: ${selSummary}${walknotes?'\nWALK NOTES: '+walknotes:''}${propnotes?'\nSCOPE NOTES: '+propnotes:''}`;

    const jobName = (addr.split(',')[0] || addr).substring(0, 26) + ' MP';
    const jobCF = { 'Sales Rep': 'Lou', 'Status': 'New Lead' };
    if (listd)      jobCF['Target List Date'] = listd;
    if (agent)      jobCF['Referring Agent'] = agent;
    if (brokerage)  jobCF['Agent Brokerage'] = brokerage;
    if (agentPhone) jobCF['Agent Phone'] = agentPhone;
    if (agentEmail) jobCF['Agent Email'] = agentEmail;

    // createJob requires locationId — if no location was created, we cannot proceed
    if (!locId) throw new Error('Cannot create job — location creation failed. Check address field.');
    const jobArgs = { locationId: locId, name: jobName, description: desc, customFieldValues: jobCF };

    const jobResp = await jt({ createJob: { '$': jobArgs, createdJob: { id: {}, name: {} } } });
    const jobNode = (jobResp.createJob || (jobResp.data && jobResp.data.createJob) || {}).createdJob || {};
    const jobId = jobNode.id;
    if (!jobId) throw new Error('Could not get job ID from: ' + JSON.stringify(jobResp).substring(0,200));
    ok('Job created: ' + jobName);

    // ── 4. Seller contact ──
    if (phone || email) {
      try {
        const cf = {};
        if (phone) cf['Phone'] = phone;
        if (email) cf['Email'] = email;
        await jt({ createContact: { '$': { accountId: custId, name: seller, customFieldValues: cf }, createdContact: { id: {} } } });
        ok('Seller contact added');
      } catch(e) { err('Contact warning: ' + e.message); }
    }

    // ── 5. Location custom fields ──
    if (locId && (access || sqft || yearbuilt)) {
      try {
        const lcf = {};
        if (access)    lcf['Entry Code'] = access;
        if (sqft)      lcf['Living Area (sqft)'] = sqft;
        if (yearbuilt) lcf['Year Built'] = yearbuilt;
        await jt({ updateLocation: { '$': { id: locId, customFieldValues: lcf }, updateLocation: {} } });
        ok('Location details set');
      } catch(e) { err('Location fields warning: ' + e.message); }
    }

    // ── 6. Apply base package template ──
    inf('Applying base package template...');
    try {
      await jt({ createCostGroup: { '$': { jobId, organizationCostGroupId: '22PVLUL5nzEk' }, createdCostGroup: { id: {} } } });
      ok('Pre-Listing Market Prep template applied');
    } catch(e) { err('Template warning: ' + e.message); }

    // ── 7. Agent account ──
    if (agent) {
      try {
        const agentResp = await jt({
          createAccount: {
            '$': {
              organizationId: ORG_ID,
              name: agent + (brokerage ? ' — ' + brokerage : ''),
              type: 'customer',
              customFieldValues: {
                'Needs': 'Other', 'Lead score': '\u2b50\u2b50\u2b50',
                'Areas To Renovate (All That Apply)': 'Other',
                'Budget Range': 'Under $15,000', 'Start Timeline': 'Just exploring',
                'Goal': 'Sell / List', 'Property Currently Occupied?': 'Vacant'
              }
            },
            createdAccount: { id: {} }
          }
        });
        const agentId = ((agentResp.createAccount || (agentResp.data && agentResp.data.createAccount) || {}).createdAccount || {}).id;
        const acf = {};
        if (agentPhone) acf['Phone'] = agentPhone;
        if (agentEmail) acf['Email'] = agentEmail;
        if (brokerage)  acf['Notes'] = 'Brokerage: ' + brokerage;
        await jt({ createContact: { '$': { accountId: agentId, name: agent, title: 'Referring Agent', customFieldValues: acf }, createdContact: { id: {} } } });
        const note = 'REFERRING AGENT: ' + agent + (brokerage?' | '+brokerage:'') + (agentPhone?' | '+agentPhone:'') + (agentEmail?' | '+agentEmail:'');
        await jt({ createComment: { '$': { targetType: 'job', targetId: jobId, message: note, isPinned: true, isVisibleToInternalRoles: true }, createdComment: { id: {} } } });
        ok('Agent account created and linked');
      } catch(e) { err('Agent warning: ' + e.message); }
    }

    // ── 8. Selections ──
    if (selections.length) {
      inf('Adding ' + selections.length + ' selections...');
      // Map catalog category to base package group name for correct budget placement
      var catToGroup = {
        'doorHardware':      'Market Prep 3 - Door Hardware',
        'lightFixtures':     'Market Prep 4 - Light Fixture Replacement',
        'electricalDevices': 'Market Prep 5 - Device Replacement',
        'bathHardware':      'Market Prep 16 — Plumbing Trim',
        'cabinetHardware':   'Market Prep 17 — Cabinet Hardware',
        'hvac':              'Market Prep 9 — Consumables and Fasteners'
      };
      for (var si = 0; si < selections.length; si++) {
        var sel = selections[si];
        try {
          var locStr = (sel.locations||[]).filter(function(l){return l;}).join(', ') || 'Location TBD';
          var groupName = catToGroup[sel.catKey] || 'Selections';
          // Build rich description with all selection details
          var desc = 'Style: ' + (sel.name||'') 
            + '\nFinish: ' + (sel.finish||'')
            + '\nQuantity: ' + (sel.qty||1)
            + '\nLocation(s): ' + locStr
            + '\nUnit price: $' + (sel.price ? sel.price.toFixed(2) : '0.00')
            + '\nTotal: $' + (sel.price && sel.qty ? (sel.price * sel.qty).toFixed(2) : '0.00');
          await jt({ createCostItem: { '$': { 
            jobId,
            organizationCostItemId: sel.id,
            quantity: sel.qty || 1,
            description: desc,
            groupName: groupName,
            showDescription: true,
            showQuantity: true
          }, createdCostItem: { id: {}, name: {} } } });
          ok('Added: ' + (sel.name||'selection') + ' x' + (sel.qty||1) + ' — ' + (sel.finish||''));
        } catch(e) { err('Selection ' + (sel.name||si) + ': ' + e.message); }
      }
      ok('All ' + selections.length + ' selections added to budget');
    }

    // ── 9. Proposal document ──
    try {
      await jt({ createDocument: { '$': { jobId, type: 'customerOrder', documentTemplateId: '22PPCQZbCZSg', name: 'Proposal — Pre-Listing Market Prep', accountId: custId, fromName: 'LMC Contracting' }, createdDocument: { id: {} } } });
      ok('Proposal document created');
    } catch(e) { err('Proposal warning: ' + e.message); }

    // ── 10. Purchase Order ──
    try {
      await jt({ createDocument: { '$': { jobId, type: 'vendorOrder', documentTemplateId: '22PCgcVGSysM', name: 'PO — ' + addr.split(',')[0], accountId: '22PEnZwGDc7H', fromName: 'LMC Contracting' }, createdDocument: { id: {} } } });
      ok('Purchase Order created');
    } catch(e) { err('PO warning: ' + e.message); }

    ok('Done! Open JobTread to review. Job ID: ' + jobId);

    return {
      statusCode: 200,
      headers: CORS,
      body: JSON.stringify({ success: true, jobId, log })
    };

  } catch(e) {
    err('Error: ' + e.message);
    return {
      statusCode: 500,
      headers: CORS,
      body: JSON.stringify({ success: false, log, error: e.message })
    };
  }
};
